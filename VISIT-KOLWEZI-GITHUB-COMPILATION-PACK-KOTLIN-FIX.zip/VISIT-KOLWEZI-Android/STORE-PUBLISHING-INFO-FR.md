# VISIT KOLWEZI — informations de publication

## Identité
- Nom : VISIT KOLWEZI
- Version : 1.0.0
- Version code : 1
- Package Android : cd.visitkolwezi.app
- Catégorie : Voyage / Local
- Site : https://lwezivisit.netlify.app/

## Description courte
Découvrez Kolwezi autrement : hôtels, restaurants, lieux à visiter, carte GPS, météo, photos, avis, contacts et réservations.

## Description longue
VISIT KOLWEZI est une application dédiée à la découverte de Kolwezi et de ses principaux lieux d'intérêt.

L'application permet notamment de :
- découvrir des hôtels, restaurants, établissements et sites de Kolwezi ;
- consulter des photos et descriptions ;
- utiliser une carte avec localisation GPS ;
- consulter la météo ;
- contacter certains établissements via WhatsApp ;
- consulter les réseaux sociaux ;
- laisser un avis ;
- accéder rapidement aux informations utiles pour explorer Kolwezi.

## Icône
L'icône officielle utilisée dans le projet est le logo fourni et retouché pour VISIT KOLWEZI.

## Distribution prévue
- Uptodown : APK Android
- Samsung Galaxy Store : APK Android

## Important
La compilation APK doit être effectuée avec Android SDK/Gradle. La publication sur les stores nécessite ensuite les comptes développeur/Seller Portal du propriétaire et la validation des plateformes.
